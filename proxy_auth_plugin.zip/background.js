
    var config = {
            mode: "fixed_servers",
            rules: {
              singleProxy: {
                scheme: "http",
                host: "in.proxymesh.com",
                port: parseInt(31280)
              },
              bypassList: ["localhost"]
            }
    };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {authCredentials: {username: "PGH", password: "prajwal2003@"}};
        },
        {urls: ["<all_urls>"]},
        ["blocking"]
    );
    